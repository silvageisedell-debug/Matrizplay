// Endereço da API do ranking. Na Vercel não precisa mudar nada.
window.MP_API='/api/ranking';
